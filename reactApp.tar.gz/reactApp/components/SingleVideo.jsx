import React from 'react';
import ReactDOM from 'react-dom';

class SingleVideo extends React.Component{
  render(){
    return(
      <div>
        <img src="https://blog.majestic.com/wp-content/uploads/2010/10/Video-Icon-crop.png"></img>
      </div>
    );
  }
}


export default SingleVideo;
