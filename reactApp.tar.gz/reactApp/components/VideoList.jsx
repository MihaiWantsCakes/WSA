import React from 'react';
import ReactDOM from 'react-dom';

class VideoList extends React.Component {
  render(){
    return(
      <div>
        <ul>
          <li>Video #1</li>
          <li>Video #2</li>
          <li>Video #3</li>
          <li>Video #4</li>
          <li>Video #5</li>
        </ul>
      </div>
    );
  }
}

export default VideoList;
