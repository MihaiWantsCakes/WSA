import React from 'react';
import ReactDOM from 'react-dom';




class Homepage extends React.Component{
  constructor(props){
    super(props);
  }

  render(){
    return(
      <div>
        <h3>Welcome to homepage!</h3>
      </div>
    );
  }
}


export default Homepage;
